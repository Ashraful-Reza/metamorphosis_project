# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
import re
from odoo.exceptions import ValidationError

class Visitors(models.Model):
    _inherit = ['res.partner']
   
    
    is_visitor = fields.Boolean(string='Is Visitor', default=False)
    visitor_id = fields.Many2one('res.partner', string='Visitor')
    purpose = fields.Char(string='Purpose', tracking=True)  
    check_in = fields.Datetime(string='Check In', default=fields.Datetime.now, required=True, tracking=True)
    check_out = fields.Datetime(string='Check Out', tracking=True)
    
    # Link to Employee
    employee_to_meet = fields.Many2one('hr.employee', string='Meeting With', help="Select the employee the visitor is meeting.", tracking=True)

    comment = fields.Text(string="Notes")
    
    @api.constrains('mobile')
    def _check_mobile_number(self):
        for record in self:
            if record.mobile and not re.match(r'^\+?\d{7,15}$', record.mobile):
                raise ValidationError("Please enter a valid mobile number (7-15 digits, with optional '+').")
class YourModel(models.Model):
    _name = 'your.model'
    _description = 'Your Model'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    # Your fields here
    name = fields.Char(tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done')
    ], default='draft', tracking=True)
    partner_id = fields.Many2one('res.partner', tracking=True)
    date = fields.Date(tracking=True)