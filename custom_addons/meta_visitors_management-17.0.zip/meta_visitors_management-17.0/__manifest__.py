{
    'name': 'Visitors Management',
    
    'summary': "Visitors Management System for offices.",
    'description': """
        A system to manage office visitors efficiently. 
        Features:
        - Visitor check-in/check-out tracking
        - Employee visitor logs
        - Integration with HR and Contacts modules""",
    
    'author':"Metamorphosis Ltd, Tanjil",
    'co-author':"Tanjil",
    'website':'https://metamorphosis.com.bd',

    'version': '17.0.0.1',
    'category': 'Tools/Tools',
    'license': 'AGPL-3',
    
    'depends': ['base', 'web', 'hr', 'contacts', 'mail'],
    'data': [
        'views/visitors_management_menu.xml',
    ],

    'sequence':-150,
    "installable": True,
    "application": True,
    'auto_install': False,
}