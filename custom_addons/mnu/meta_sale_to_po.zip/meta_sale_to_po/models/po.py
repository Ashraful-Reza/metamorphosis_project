# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import AccessError, ValidationError, UserError
import logging

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    @api.model
    def main_sotopo_record(self):
        logging.info(f"Finding Record For S2P------>From: {self.name} origin: {self.origin}")
        sopo=self.env['so.to.po'].sudo().search([('name','=',self.origin)],limit=1)
        if sopo:
            logging.info(f"sopo------------from po------->{sopo.name}")
            sopo.action_make_done_sopo()
        else:
            pass
        return True           

    def action_po_bulk_cancel(self):
        if self.filtered(lambda so: so.state != 'cancel' and so.state=='draft'):
            for order in self:                
                order.state='cancel'
                order.main_sotopo_record()
        else:
            raise UserError(_('In order to cancel a purchase order, you must be a Draft record.'))
    
    def button_confirm(self):
        for order in self:
            if order.state not in ['draft', 'sent']:
                continue
            order.order_line._validate_analytic_distribution()
            order._add_supplier_to_product()
            # Deal with double validation process
            if order._approval_allowed():
                order.button_approve()
            else:
                order.write({'state': 'to approve'})
            if order.partner_id not in order.message_partner_ids:
                order.message_subscribe([order.partner_id.id])
            
            order.main_sotopo_record()

        return True
   
    def button_unlock(self):
        self.write({'state': 'purchase'})
        self.main_sotopo_record()

    def button_done(self):
        self.write({'state': 'done', 'priority': '0'})
        self.main_sotopo_record()