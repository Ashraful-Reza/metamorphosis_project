# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import AccessError, ValidationError
import logging

class SaleToPurchaseBomLine(models.Model):
    _name = 'so.to.po.bom.line'
    _description = 'Sale To Purchase BOM Line'
    _check_company_auto = True
    
    so_to_po_id = fields.Many2one(
        'so.to.po',
        string='Sale To Purchase',
        required=True,
        ondelete='cascade')
        
    bom_id = fields.Many2one(
        'mrp.bom',
        string='Bill of Material',
        required=True)
        
    product_id = fields.Many2one(
        'product.product',
        string='Product',
        required=True)
        
    product_qty = fields.Float(
        string='Quantity',
        default=1.0)
        
    company_id = fields.Many2one(related='so_to_po_id.company_id',store=True)

    @api.onchange('product_qty')
    def _onchange_product_qty(self):
        """Trigger purchase lines recomputation when quantity changes"""
        for rec in self:
            if rec.so_to_po_id and rec.so_to_po_id.state == 'confirmed':
                for bli in rec.so_to_po_id.bom_line_ids:
                    bom = bli.bom_id
                    for component in bom.bom_line_ids:
                        component_qty = component.product_qty * bli.product_qty if bli.product_qty!=0 else 1
                        existing_lines = self.env['so.to.po.line'].sudo().search([
                        ('so_to_po_id', '=', rec.so_to_po_id._origin.id if rec.so_to_po_id._origin else rec.so_to_po_id.id),
                        ('product_id', '=', component.product_id.id),
                        ])
                        for el in existing_lines:
                            el.product_qty = component_qty
            rec.so_to_po_id.state = 'confirmed'

