# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class SaleToPurchaseLine(models.Model):
    _name = 'so.to.po.line'
    _description = 'Sale To Purchase Line'
    _check_company_auto = True
    
    so_to_po_id = fields.Many2one('so.to.po',string='Sale To Purchase',ondelete='cascade')
        
    product_id = fields.Many2one('product.product',string='Product',required=True)
        
    product_qty = fields.Float(string='Quantity',required=True,default=1.0)
        
    company_id = fields.Many2one(related='so_to_po_id.company_id',store=True)
        
    currency_id = fields.Many2one(related='so_to_po_id.currency_id')

    vendor_id = fields.Many2one('res.partner',string='Vendor',compute='_compute_vendor',store=True)

    so_bom_id=fields.Many2one(comodel_name="so.to.po.bom.line",string="Source BOM",ondelete='cascade')
    
    @api.depends('product_id', 'product_qty')
    def _compute_vendor(self):
        """Compute the main vendor for the product"""
        for line in self:
            seller = line.product_id.pd_supplier
            line.vendor_id = seller.id if seller else False