# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import AccessError, ValidationError
from collections import defaultdict
import logging
from odoo.exceptions import ValidationError


class SaleToPurchase(models.Model):
    _name = 'so.to.po'
    _description = 'Sale To Purchase'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _check_company_auto = True
    _order = 'date_order desc, id desc'

    name = fields.Char(string="Reference",required=True, copy=False, readonly=True,index='trigram',default=lambda self: _('New'),tracking=True)
        
    date_order = fields.Datetime(string='Date',required=True,readonly=True,index=True,default=fields.Datetime.now,copy=False,tracking=True)
        
    company_id = fields.Many2one('res.company',string='Company',required=True,index=True,default=lambda self: self.env.company,tracking=True)

    sale_order_ids = fields.Many2many('sale.order','so_to_po_sale_order_rel','so_to_po_id','sale_order_id',string='Sale Orders',domain="[('company_id', '=', company_id)]",tracking=True)
        
    bom_line_ids = fields.One2many('so.to.po.bom.line','so_to_po_id',string='BOM Lines')
        
    purchase_line_ids = fields.One2many('so.to.po.line','so_to_po_id',string='Purchase Items')

    purchase_order_ids = fields.Many2many('purchase.order','so_to_po_purchase_rel','so_to_po_id','purchase_order_id',string='Purchase Orders',readonly=True,copy=False)
        
    currency_id = fields.Many2one('res.currency',string='Currency',related='company_id.currency_id',readonly=True,store=True)

    active = fields.Boolean(default=True, string='Active')
    
    state = fields.Selection([('draft', 'Draft'),('confirmed', 'Confirmed'),('po_created', 'POs Created'),('done', 'Done'),('cancel', 'Cancelled')], string='Status', default='draft', tracking=True)

    purchase_order_count = fields.Integer(compute='_compute_purchase_order_count',string='Purchase Order Count')
    
    def _compute_purchase_order_count(self):
        for record in self:
            record.purchase_order_count = len(record.purchase_order_ids)
            if record.purchase_order_count==0 and record.state not in ['confirmed','po_created','done']:
                record.state='draft'
            else:
                pass

    def action_compute_bom_lines(self):
        """Compute BOM lines from selected sale orders"""
        for record in self:
            if not record.sale_order_ids:
                raise ValidationError(_("You must select at least one sale order to confirm."))
            # Clear existing lines
            record.bom_line_ids.unlink()
            record.purchase_line_ids.unlink()
            
            bom_products = {}  # Dictionary to store cumulative quantities
            
            for sale_order in record.sale_order_ids:
                for line in sale_order.order_line:
                    bom = self.env['mrp.bom']._bom_find(
                        line.product_id,
                        company_id=record.company_id.id)[line.product_id]                    
                    if bom:
                        key = (bom.id, line.product_id.id)
                        if key not in bom_products:
                            bom_products[key] = {
                                'bom': bom,
                                'product': line.product_id,
                                'qty': 0.0
                            }
                        bom_products[key]['qty'] += line.product_uom_qty
            
            # Create BOM lines
            for key, data in bom_products.items():
                bom_data={
                    'so_to_po_id': record._origin.id if record._origin else record.id,
                    'bom_id': data['bom'].id,
                    'product_id': data['product'].id,
                    'product_qty': data['qty'],
                }
                self.env['so.to.po.bom.line'].create(bom_data)
                self.env.cr.commit()
            
            # Compute purchase lines based on BOM lines
            record.compute_purchase_lines()
    
    def compute_purchase_lines(self):
        """Compute purchase lines from BOM lines"""
        self.ensure_one()
        if not self.sale_order_ids:
         raise ValidationError(_("You must select at least one sale order to confirm."))

        purchase_items = {}
        
        for bom_line in self.bom_line_ids:
            bom = bom_line.bom_id            
            for component in bom.bom_line_ids:
                component_qty = component.product_qty * bom_line.product_qty
                key = component.product_id.id
                
                if key not in purchase_items:
                    purchase_items[key] = {
                        'product_id': component.product_id.id,
                        'product_qty': 0.0,
                        'so_bom_id':bom_line.id
                    }
                purchase_items[key]['product_qty'] += component_qty
        
        existing_lines = self.env['so.to.po.line'].search([
        ('so_to_po_id', '=', self._origin.id if self._origin else self.id)
        ])
        existing_product_ids = {line.product_id.id: line for line in existing_lines}

        lines_to_create = []
        for product_id, data in purchase_items.items():
            if product_id in existing_product_ids:
                # Update existing line
                existing_product_ids[product_id].write({
                    'product_qty': data['product_qty']
                })
            else:
                # Prepare new line
                lines_to_create.append({
                    'so_to_po_id': self._origin.id if self._origin else self.id,
                    'so_bom_id': data['so_bom_id'],
                    'product_id': data['product_id'],
                    'product_qty': data['product_qty'],
                })
        
        # Create new lines
        if lines_to_create:
            self.env['so.to.po.line'].create(lines_to_create)
            self.env.cr.commit()
        
        # Remove lines for products that are no longer needed
        obsolete_lines = existing_lines.filtered(
            lambda l: l.product_id.id not in purchase_items
        )
        if obsolete_lines:
            obsolete_lines.unlink()
        
        self.state="confirmed"

    def action_create_purchase_orders(self):
        """Create purchase orders based on suppliers"""
        self.ensure_one()
        if not self.purchase_line_ids:
            raise ValidationError(_("No purchase items to order."))

        # Group products by supplier
        supplier_products = defaultdict(list)
        for line in self.purchase_line_ids:
            seller = line.product_id.pd_supplier
            product_id=line.product_id
            quantity=line.product_qty
            date=fields.Date.today()
            uom_id=line.product_id.uom_po_id
            
            if not seller:
                raise ValidationError(_(
                    "No vendor found for product: %s. Please set a vendor first."
                ) % line.product_id.display_name)
                
            supplier_products[seller.id].append((product_id, quantity))

        po_ids = []
        # Create PO for each supplier
        logging.info(f"supplier_products-------------------->{supplier_products}")
        PurchaseOrder = self.env['purchase.order']
        for supplier, products in supplier_products.items():
            supplier_id=self.env['res.partner'].sudo().browse(supplier)
            po_vals = {
                'partner_id': supplier,
                'company_id': self.company_id.id,
                'currency_id': supplier_id.property_purchase_currency_id.id or self.company_id.currency_id.id,
                'origin': self.name,
                'date_order': fields.Datetime.now(),
            }
            
            purchase_order = PurchaseOrder.create(po_vals)
            po_ids.append(purchase_order.id)
            
            for product, qty in products:
                self.env['purchase.order.line'].create({
                    'order_id': purchase_order.id,
                    'product_id': product.id,
                    'name': product.name,
                    'product_qty': qty,
                    'product_uom': product.uom_po_id.id,
                    'price_unit': product.standard_price,
                    'date_planned': fields.Datetime.now(),
                })

        self.write({
            'purchase_order_ids': [(6, 0, po_ids)],
            'state': 'po_created'
        })
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Purchase Orders'),
            'res_model': 'purchase.order',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', po_ids)],
        }

    def action_view_purchase_orders(self):
        """Smart button action to view related purchase orders"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Purchase Orders'),
            'res_model': 'purchase.order',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.purchase_order_ids.ids)],
            'context': {'create': False}
        }

    def _check_company_id(self, company_id):
        """Ensure proper company access."""
        if company_id and company_id != self.env.company.id:
            raise AccessError(_("You cannot create/modify records for a different company than your own."))
        return True

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            company_id = vals.get('company_id', self.env.company.id)
            self._check_company_id(company_id)
            
            if company_id:
                self = self.with_company(company_id)
                
            if vals.get('name', _('New')) == _('New'):
                seq_date = None
                if 'date_order' in vals:
                    seq_date = fields.Datetime.context_timestamp(
                        self, fields.Datetime.to_datetime(vals['date_order']))
                    
                vals['name'] = self.env['ir.sequence'].next_by_code(
                    'so.to.po',
                    sequence_date=seq_date) or _('New')

        records = super().create(vals_list)
        return records

    def write(self, vals):
        """Override write to update state based on PO changes"""
        if 'company_id' in vals:
            self._check_company_id(vals['company_id'])
            
        res = super().write(vals)
        
        if 'purchase_order_count' in vals and vals['purchase_order_count']>0:
            for record in self:
                if not record.purchase_order_ids and record.state == 'po_created':
                    record.state = 'confirmed'
        else:
            pass
        return res
    
    def action_cancel_sopo(self):
        for record in self:
            if record.state != 'cancel':
                if record.purchase_order_count>0:
                    record.purchase_order_ids.action_po_bulk_cancel()
                    record.state = 'cancel'
                else:
                    record.state = 'draft'
    
    def action_make_draft_sopo(self):
        for record in self:
            if record.state not in ['draft','po_created','done']:
                record.state = 'draft'
    
    def action_make_done_sopo(self):
        logging.info(f"Got Hit From ---> action_make_done_sopo() .. i repeat .. over ! over !.")
        for record in self:
            logging.info(f"Bullet Finished only remained ---> {len(record.purchase_order_ids.filtered(lambda x: x.state not in ['purchase','done','cancel']))}")
            if record.state=='po_created' and len(record.purchase_order_ids.filtered(lambda x: x.state not in ['purchase','done','cancel']))==0:
                # record.state=='done'
                self.write({'state': 'done'})
            else:
                pass
    