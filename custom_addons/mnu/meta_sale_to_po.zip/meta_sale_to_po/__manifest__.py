# -*- coding: utf-8 -*-
{
    'name': "Sale Order To Purchase Order",

    'summary': """This module will help to automatically create the purchaser order from different supplier based on the sale orders bom product.""",

    'description': """This module will help to automatically create the purchaser order from different supplier based on the sale orders bom product.""",

    'author': "Metamorphosis LTD, Rifat Anwar",
    'co-author': "Rifat Anwar",
    'website': "https://metamorphosis.com.bd",
    'category': 'Tools/Tools',
    'version': '17.0.0.1',
    
    'depends': ['sale_stock','purchase','one2many_search_widget'],
    'data': [
        'security/ir.model.access.csv',
        'data/seq_data.xml',
        'views/so_to_po_view.xml',
    ],
    
    'sequence':-100,
    'license':'AGPL-3',
    'installable':True,
    'auto-installable':False,
    'application':True,
    
}
